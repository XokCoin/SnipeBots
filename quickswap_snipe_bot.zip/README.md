Guide on using this snipe bot:
1. Download Node JS from https://nodejs.org/en/download/, the LTS version is fine
2. Open terminal/cmd inside this folder, type `npm install` without the backticks
3. Using any text editor open the file `userInput.js` where you need to follow the instructions and fill in the inputs properly
4. Run the commands as listed inside `userInput.js`, such as `node query.js` and `node buy.js`